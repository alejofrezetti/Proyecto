﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Empresa
{
    [Serializable]
    public class MiEmpresa
    {
        private List<Aeropuerto> aeropuertos=new List<Aeropuerto>();
        private List<Usuario> usuarios = new List<Usuario>();
        public List<Aeropuerto> Aeropuertos { get { return aeropuertos; } set { aeropuertos = value; } }
        public List<Usuario> Usuarios { get { return usuarios; } set { usuarios = value; } }

        public Aeropuerto BuscarAeropuertoPorNombre(string _nombre)
        {
            foreach (Aeropuerto aeropuerto in aeropuertos)
                if (aeropuerto.nombre == _nombre)
                    return aeropuerto;

            throw new AeropuertoNoEncontrado();
        }

        public bool ExisteVuelo(int _numero)
        {
            foreach (Aeropuerto aeropuerto in aeropuertos)
                foreach (Aerolinea aerolinea in aeropuerto.Aerolineas)
                    if (aerolinea.ContieneElVuelo(_numero)) return true;

            return false;
        
        }

            
    }
}
