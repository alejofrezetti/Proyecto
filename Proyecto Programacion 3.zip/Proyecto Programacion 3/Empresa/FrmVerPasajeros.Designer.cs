﻿namespace Empresa
{
    partial class FrmVerPasajeros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPasajeros = new System.Windows.Forms.Label();
            this.btnVolver = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelPasajeros
            // 
            this.labelPasajeros.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPasajeros.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelPasajeros.Location = new System.Drawing.Point(22, 9);
            this.labelPasajeros.Name = "labelPasajeros";
            this.labelPasajeros.Size = new System.Drawing.Size(403, 391);
            this.labelPasajeros.TabIndex = 1;
            this.labelPasajeros.Click += new System.EventHandler(this.labelPasajeros_Click);
            // 
            // btnVolver
            // 
            this.btnVolver.Location = new System.Drawing.Point(406, 403);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(111, 34);
            this.btnVolver.TabIndex = 21;
            this.btnVolver.Text = "Volver";
            this.btnVolver.UseVisualStyleBackColor = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // FrmVerPasajeros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(529, 450);
            this.ControlBox = false;
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.labelPasajeros);
            this.Name = "FrmVerPasajeros";
            this.Text = "FrmVerPasajeros";
            this.Load += new System.EventHandler(this.FrmVerPasajeros_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelPasajeros;
        private System.Windows.Forms.Button btnVolver;
    }
}