﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace Empresa
{
    [Serializable]
    public class Usuario
    {
        public string nombre { get; set; }
        public string contrasena { get; set; }

        public string dni { get; set; }
        public string nacionalidad { get; set; }
        public Vuelo vuelo { get; set; }
        public bool esAdmin { get; set; }

        public Usuario(string Nombre, string Contrasena, string DNI, string Nacionalidad, bool EsAdmin)
        {
            nombre = Nombre;
            contrasena = Contrasena;
            dni = DNI;
            nacionalidad = Nacionalidad;
            esAdmin = EsAdmin;
            vuelo = null;
        }

        

    }
}
