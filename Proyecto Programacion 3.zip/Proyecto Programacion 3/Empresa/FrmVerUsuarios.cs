﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmVerUsuarios : Form
    {
        private FrmMenuAdmin frmMenuAdmin;
        public FrmVerUsuarios(FrmMenuAdmin _frmMenuAdmin)
        {
            InitializeComponent();
            frmMenuAdmin = _frmMenuAdmin;

        }

        private void VerUsuarios_Load(object sender, EventArgs e)
        {
           
            foreach( Usuario u in Program.Empresa.Usuarios)
            {
                if (u.esAdmin == true) labelUsuarios.Text += "Administrador || ";
                else labelUsuarios.Text += "     Cliente      || ";
                labelUsuarios.Text +=" Nombre: " + u.nombre + "  ||  Contraseña: " + u.contrasena + "  ||\n";
            }
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmMenuAdmin.Show();
            this.Hide();
        }

        private void labelUsuarios_Click(object sender, EventArgs e)
        {

        }
    }
}
