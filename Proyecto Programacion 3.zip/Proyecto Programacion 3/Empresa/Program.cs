﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Empresa
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>

        private static Usuario usuarioActual;
        public static Usuario UsuarioActual { get { return usuarioActual; } set { usuarioActual = value; } }

        private static MiEmpresa empresa = new MiEmpresa();
        public static MiEmpresa Empresa { get { return empresa; } set { empresa = value; } }

        [STAThread]
        static void Main()
        {
            Application.ApplicationExit += new System.EventHandler(SerializarAlSalir);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmLogin());
            
        }

        public static void SerializarAlSalir(object sender, EventArgs e)
        {
            Stream flujo2 = File.Create("Datos.bin");
            BinaryFormatter serializer = new BinaryFormatter();
            serializer.Serialize(flujo2, empresa);  
            flujo2.Close();
            //MessageBox.Show("Guardando...");
        }

        
    }
}
