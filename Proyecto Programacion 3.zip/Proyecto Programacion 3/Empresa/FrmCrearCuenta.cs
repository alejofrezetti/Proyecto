﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Empresa
{
    public partial class FrmCrearCuenta : Form
    {
        private FrmLogin frmLogin;
        public FrmCrearCuenta(FrmLogin _frmLogin)
        {
            InitializeComponent();
            frmLogin = _frmLogin;
            

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkAdmin.Checked == true)
            {
                labelclave.Visible = true;
                txtClave.Visible = true;
                label5.Visible = true;
            }
            else
            {
                labelclave.Visible = false;
                txtClave.Visible = false;
                label5.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if (checkAdmin.Checked == false)
            {
                Usuario usuario = new Usuario(txtNombre.Text,txtContrasena.Text,txtDni.Text, txtNacionalidad.Text, checkAdmin.Checked );
                Program.Empresa.Usuarios.Add(usuario);
                frmLogin.Show();
                this.Hide();
                
            }

            if (checkAdmin.Checked == true && txtClave.Text == "clave123")
            {
                Usuario usuario = new Usuario(txtNombre.Text, txtContrasena.Text, txtDni.Text, txtNacionalidad.Text, checkAdmin.Checked);
                Program.Empresa.Usuarios.Add(usuario);
                frmLogin.Show();
                this.Hide();
            }

            else
            {
                if(checkAdmin.Checked == true && !(txtClave.Text == "clave123"))
                MessageBox.Show("Clave de administrador incorrecta");
            }



        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmLogin.Show();
            this.Hide();
        }

        private void FrmCrearCuenta_Load(object sender, EventArgs e)
        {

        }

        

    }
}
