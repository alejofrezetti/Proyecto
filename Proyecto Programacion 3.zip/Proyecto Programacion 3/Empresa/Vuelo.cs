﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa
{
    [Serializable]
    public class Vuelo
    {
        private List<Usuario> pasajeros;
        public int numero { get; set; }
        public string origen { get; set; }
        public string destino { get; set; }
        public double precio { get; set; }
        public int asientosTotales { get; set; }
        public int asientosDisponibles { get; set; }
        public string fecha { get; set; }
        public string hora { get; set; }
        public string aeropuerto { get; set; }
        public string aerolinea { get; set; }
        public List<Usuario> Pasajeros { get { return pasajeros; } set { pasajeros = value; } }

        public Vuelo(int Numero, string Origen, string Destino, double Precio, 
            int AsientosTotales, int AsientosDisponibles, string Fecha, string Hora, string Aeropuerto, string Aerolinea)
        {
            pasajeros = new List<Usuario>();
            numero = Numero;
            origen = Origen;
            destino = Destino;
            precio = Precio;
            asientosTotales = AsientosTotales;
            asientosDisponibles = AsientosDisponibles;
            fecha = Fecha;
            hora = Hora;
            aeropuerto = Aeropuerto;
            aerolinea = Aerolinea;
            
        }

    }
}
