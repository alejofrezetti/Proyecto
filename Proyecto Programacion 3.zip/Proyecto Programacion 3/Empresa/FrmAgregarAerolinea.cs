﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmAgregarAerolinea : Form
    {
        private FrmMenuAdmin frmMenuAdmin;
        
        public FrmAgregarAerolinea(FrmMenuAdmin _frmMenuAdmin)
        {
            InitializeComponent();
            frmMenuAdmin = _frmMenuAdmin;
            
        }

        private void FrmAgregarAerolinea_Load(object sender, EventArgs e)
        {
            
            foreach (Aeropuerto a in Program.Empresa.Aeropuertos)
                    comboAeropuerto.Items.Add(a.nombre);
            
            
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmMenuAdmin.Show();
            this.Hide();
        }

        private void comboAeropuerto_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNombre.Text != "")
                {
                    Program.Empresa.BuscarAeropuertoPorNombre(comboAeropuerto.Text).Aerolineas.Add(new Aerolinea(txtNombre.Text));
                    MessageBox.Show("¡Agregada con exito!");
                }
                else
                    MessageBox.Show("Por favor complete los campos restantes");
            }
            catch(AeropuertoNoEncontrado)
            {
                MessageBox.Show("Complete el campo Aeropuerto");
            }

        }
    }
}
