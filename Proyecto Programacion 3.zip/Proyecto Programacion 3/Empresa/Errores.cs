﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    class AeropuertoNoEncontrado : Exception { }
    class AerolineaNoEncontrada : Exception { }
    class VueloNoEncontrado : Exception { }

}
