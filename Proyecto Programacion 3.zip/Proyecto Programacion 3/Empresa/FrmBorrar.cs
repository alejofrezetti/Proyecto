﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmBorrar : Form
    {
        private FrmMenuAdmin frmMenuAdmin;
        public FrmBorrar(FrmMenuAdmin _frmMenuAdmin)
        {
            InitializeComponent();
            frmMenuAdmin = _frmMenuAdmin;
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmMenuAdmin.Show();
            this.Hide();
        }

        private void btnBorrarAeropuerto_Click(object sender, EventArgs e)
        {
            try
            {
                Program.Empresa.Aeropuertos.Remove(Program.Empresa.BuscarAeropuertoPorNombre(comboAeropuerto.Text));
                MessageBox.Show("Borrado con exito");
                comboAeropuerto.Text = "";
                RefrescarComboBox();
            }
            catch (AeropuertoNoEncontrado) {
                MessageBox.Show("Complete el campo Aeropuerto"); 
            }

        }

        private void FrmBorrar_Load(object sender, EventArgs e)
        {
            foreach (Aeropuerto a in Program.Empresa.Aeropuertos)
            {
                comboAeropuerto.Items.Add(a.nombre);
                comboAeropuerto2.Items.Add(a.nombre);
            }
            
            foreach (Aeropuerto a in Program.Empresa.Aeropuertos)
            {
                foreach (Aerolinea b in a.Aerolineas)
                {
                    if (!comboAerolinea.Items.Contains(b.Nombre)) 
                        comboAerolinea.Items.Add(b.Nombre);
                }
            }
        }

        private void btnBorrarAerolinea_Click(object sender, EventArgs e)
        {
            if (comboAerolinea.Text != "")
            {
                foreach (Aeropuerto aeropuerto in Program.Empresa.Aeropuertos)
                    if (aeropuerto.ContieneLaAerolinea(comboAerolinea.Text))
                        aeropuerto.Aerolineas.Remove(aeropuerto.BuscarAerolineaPorNombre(comboAerolinea.Text));

                MessageBox.Show("Borrado con exito");
                RefrescarComboBox();
            }
            else MessageBox.Show("Complete el campo Aerolinea");

        }

        private void btnBorrarVuelo_Click(object sender, EventArgs e)
        {
            if (txtNumero.Text != "")
            {
                int numeroVueloABorrar = Int32.Parse(txtNumero.Text);

                foreach (Aeropuerto aeropuerto in Program.Empresa.Aeropuertos)
                    foreach (Aerolinea aerolinea in aeropuerto.Aerolineas)
                        if (aerolinea.ContieneElVuelo(numeroVueloABorrar))
                        {
                            aerolinea.Vuelos.Remove(aerolinea.BuscarVueloPorNumero(numeroVueloABorrar));
                            txtNumero.Text = "";
                            MessageBox.Show("Borrado con exito");
                        }
            }
            else MessageBox.Show("Escriba un numero de vuelo");
                       
        }

        public void RefrescarComboBox()
        {

            comboAerolinea.Items.Clear();
            comboAeropuerto.Items.Clear();
            comboAerolinea.Text = "";
            comboAeropuerto.Text = "";
            comboAeropuerto2.Items.Clear();
            comboAerolinea2.Items.Clear();
            comboAerolinea2.Text = "";
            comboAeropuerto2.Text = "";



            foreach (Aeropuerto a in Program.Empresa.Aeropuertos)
            {
                comboAeropuerto.Items.Add(a.nombre);
                comboAeropuerto2.Items.Add(a.nombre);
            }

            foreach (Aeropuerto a in Program.Empresa.Aeropuertos)
            {
                foreach (Aerolinea b in a.Aerolineas)
                {
                    if (!comboAerolinea.Items.Contains(b.Nombre))
                        comboAerolinea.Items.Add(b.Nombre);
                    if (!comboAerolinea2.Items.Contains(b.Nombre))
                        comboAerolinea2.Items.Add(b.Nombre);
                }
            }
        }

        private void comboAeropuerto2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboAerolinea2.Items.Clear();
            foreach (Aerolinea aerolinea in Program.Empresa.BuscarAeropuertoPorNombre(comboAeropuerto2.Text).Aerolineas)
                comboAerolinea2.Items.Add(aerolinea.Nombre);

        }

        private void btnBorrarAerolineaSegunAeropuerto_Click(object sender, EventArgs e)
        {
            if (comboAeropuerto2.SelectedItem != null && comboAerolinea2.SelectedItem != null)
            {
                Program.Empresa.BuscarAeropuertoPorNombre(comboAeropuerto2.Text).Aerolineas.Remove(
                                Program.Empresa.BuscarAeropuertoPorNombre(comboAeropuerto2.Text).BuscarAerolineaPorNombre(comboAerolinea2.Text));
                MessageBox.Show("Borrado Exitoso!");
            }
            else MessageBox.Show("Complete los campos");
            RefrescarComboBox();

        }
    }
}
