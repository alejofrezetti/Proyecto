﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmMenuAdmin : Form
    {
        private FrmLogin frmLogin;
        private FrmAgregarAerolinea frmAgregarAerolinea;
        private FrmAgregarAeropuerto frmAgregarAeropuerto;
        private FrmAgregarVuelo frmAgregarVuelo;
        private FrmBorrar frmBorrar;
        private FrmVerUsuarios frmVerUsuarios;
        private FrmVerVuelos frmVerVuelos;

        public FrmMenuAdmin(FrmLogin _frmLogin)
        {
            InitializeComponent();
            frmLogin = _frmLogin;
            frmAgregarAerolinea = new FrmAgregarAerolinea(this);
            frmAgregarAeropuerto = new FrmAgregarAeropuerto(this);
            frmAgregarVuelo = new FrmAgregarVuelo(this);
            frmBorrar = new FrmBorrar(this);
            frmVerUsuarios = new FrmVerUsuarios(this);
            frmVerVuelos = new FrmVerVuelos(this);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmAgregarAeropuerto.Show();
            this.Hide();
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            frmLogin.Show();
            this.Hide();
        }

        private void FrmMenuAdmin_Load(object sender, EventArgs e)
        {
            frmBorrar.RefrescarComboBox();
        }

        private void btnAgregarAerolinea_Click(object sender, EventArgs e)
        {
            frmAgregarAerolinea.Show();
            this.Hide();
        }

        private void btnAgregarVuelo_Click(object sender, EventArgs e)
        {
            frmAgregarVuelo.Show();
            this.Hide();
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            frmBorrar.Show();
            this.Hide();
            frmBorrar.RefrescarComboBox();
        }

        private void btnVerUsuarios_Click(object sender, EventArgs e)
        {
            frmVerUsuarios.Show();
            this.Hide();
        }

        private void btnVerVuelos_Click(object sender, EventArgs e)
        {
            frmVerVuelos.Show();
            this.Hide();
        }
    }
}
