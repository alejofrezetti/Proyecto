﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmAgregarVuelo : Form
    {
        private FrmMenuAdmin frmMenuAdmin;
        public FrmAgregarVuelo(FrmMenuAdmin _frmMenuAdmin)
        {
            InitializeComponent();
            frmMenuAdmin = _frmMenuAdmin;
        }

        private void FrmAgregarVuelo_Load(object sender, EventArgs e)
        {
            foreach (Aeropuerto a in Program.Empresa.Aeropuertos)
                comboAeropuerto.Items.Add(a.nombre);
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmMenuAdmin.Show();
            this.Hide();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {

            try
            {
                if ( !CamposEstanVacios())
                {
                    if (!Program.Empresa.ExisteVuelo(Int32.Parse(txtNumero.Text)))
                    {
                        Program.Empresa.BuscarAeropuertoPorNombre(comboAeropuerto.Text).BuscarAerolineaPorNombre(comboAerolinea.Text).AgregarVuelo(
                                  Int32.Parse(txtNumero.Text), txtOrigen.Text, txtDestino.Text,
                                  Double.Parse(txtPrecio.Text), Int32.Parse(txtAsientos.Text), Int32.Parse(txtAsientos.Text),
                                  txtFecha.Text, txtHora.Text, comboAeropuerto.Text, comboAerolinea.Text);

                        MessageBox.Show("Vuelo Agregado!");
                    }
                    else MessageBox.Show("El vuelo ya existe");

                }
                else MessageBox.Show("Complete los campos");
            }

            catch(AeropuertoNoEncontrado)
            {
                MessageBox.Show("Por favor complete el campo Aeropuerto");
            }
            catch (AerolineaNoEncontrada)
            {
                MessageBox.Show("Por favor complete el campo Aerolinea");
            }

        }

        private void comboAeropuerto_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboAerolinea.Items.Clear();
            foreach (Aerolinea aerolinea in Program.Empresa.BuscarAeropuertoPorNombre(comboAeropuerto.Text).Aerolineas)
                comboAerolinea.Items.Add(aerolinea.Nombre);

        }

        public bool CamposEstanVacios()
        {
            if (txtNumero.Text == "" || txtOrigen.Text == "" || txtDestino.Text == "" || txtPrecio.Text == "" || txtAsientos.Text == "" ||
                                                               txtAsientos.Text == "" || txtFecha.Text == ""  || txtHora.Text == "")
                return true;
            else 
                return false;
        }

        private void comboAerolinea_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
