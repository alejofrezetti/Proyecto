﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmBuscarVuelos : Form
    {
        private List<Vuelo> VuelosPorDestino = new List<Vuelo>();
        private int posicion=0;
        private int maxposicion;

        private FrmMenuCliente frmMenuCliente;
        public FrmBuscarVuelos(FrmMenuCliente _frmMenuCliente)
        {
            InitializeComponent();
            frmMenuCliente = _frmMenuCliente;            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void FrmBuscarVuelos_Load(object sender, EventArgs e)
        {
            
            foreach(Aeropuerto aeropuerto in Program.Empresa.Aeropuertos)
                foreach(Aerolinea aerolinea in aeropuerto.Aerolineas)
                    foreach(Vuelo vuelo in aerolinea.Vuelos)
                        if (!comboDestino.Items.Contains(vuelo.destino))
                            comboDestino.Items.Add(vuelo.destino);

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            LimpiarLabels();
            frmMenuCliente.Show();
            this.Hide();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if(comboDestino.Text != "")
            {
                VuelosPorDestino.Clear();
                ArmarListaDestinos();
                maxposicion = VuelosPorDestino.Count()-1;
                MostrarListaDestinos();
            }
            else
            {
                MessageBox.Show("Seleccione un destino");
            }
            
            
        }

        private void ArmarListaDestinos()
        {
            foreach(Aeropuerto aeropuerto in Program.Empresa.Aeropuertos)
                foreach(Aerolinea aerolinea in aeropuerto.Aerolineas)
                    foreach(Vuelo vuelo in aerolinea.Vuelos)
                        if( ( vuelo.destino==comboDestino.Text ) && (!VuelosPorDestino.Contains(vuelo)))
                            if (vuelo.asientosDisponibles != 0) VuelosPorDestino.Add(vuelo);
           
            if(VuelosPorDestino.Count==0)
                MessageBox.Show("No se encontraron vuelos disponibles con ese destino");
            
        }      
        
        private void MostrarListaDestinos()
        {
            if (VuelosPorDestino.Count > 0)
            {
                labelNumero.Text = VuelosPorDestino[posicion].numero.ToString();
                labelPrecio.Text = VuelosPorDestino[posicion].precio.ToString();
                labelOrigen.Text = VuelosPorDestino[posicion].origen;
                labelAsientos.Text = VuelosPorDestino[posicion].asientosDisponibles.ToString();
                labelFecha.Text = VuelosPorDestino[posicion].fecha;
                labelHora.Text = VuelosPorDestino[posicion].hora;
                labelAerolinea.Text = VuelosPorDestino[posicion].aerolinea;
                labelAeropuerto.Text = VuelosPorDestino[posicion].aeropuerto;
            }
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            posicion++;
            if (posicion > maxposicion)  posicion = 0; 
            MostrarListaDestinos();
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            posicion--;
            if (posicion < 0) posicion = maxposicion;
            MostrarListaDestinos();
        }

        private void comboDestino_SelectedIndexChanged(object sender, EventArgs e)
        {
            LimpiarLabels();
            posicion = 0;
        }

        public void LimpiarLabels()
        {
            labelNumero.Text = "";
            labelPrecio.Text = "";
            labelOrigen.Text = "";
            labelAsientos.Text = "";
            labelFecha.Text = "";
            labelHora.Text = "";
            labelAerolinea.Text = "";
            labelAeropuerto.Text = "";
        }

        private void btnReservar_Click(object sender, EventArgs e)
        {
            int numeroVuelo = Int32.Parse(labelNumero.Text); 
            
            if (comboDestino.Text != "")
            {
                if (Program.UsuarioActual.vuelo != null)
                    MessageBox.Show("Solo puede tener una reserva a la vez");
                else
                {
                    Program.UsuarioActual.vuelo = VuelosPorDestino[posicion];

                    foreach (Aeropuerto aeropuerto in Program.Empresa.Aeropuertos)
                        foreach (Aerolinea aerolinea in aeropuerto.Aerolineas)
                            if (aerolinea.ContieneElVuelo(numeroVuelo)) {
                                aerolinea.BuscarVueloPorNumero(numeroVuelo).Pasajeros.Add(Program.UsuarioActual);
                                aerolinea.BuscarVueloPorNumero(numeroVuelo).asientosDisponibles--;
                                MostrarListaDestinos();
                                MessageBox.Show("Reservado con exito!");
                            }
                    LimpiarLabels();
                }
            }
            else MessageBox.Show("Seleccione destino");

        }

        private void cancelar_Click(object sender, EventArgs e)
        {
            try
            {
                if (Program.UsuarioActual.vuelo == null)
                {
                    MessageBox.Show("No tiene ninguna reserva a su nombre");
                }
                else
                {
                    
                    Program.UsuarioActual.vuelo.Pasajeros.Remove(Program.UsuarioActual);
                    Program.UsuarioActual.vuelo.asientosDisponibles++;   //devuelve el asiento al vuelo
                    Program.UsuarioActual.vuelo = null;
                    MostrarListaDestinos();
                     
                    MessageBox.Show("Reserva Anulada");                                     
                }
            }
            catch
            {
                MessageBox.Show("Error");
            }      
        }
    }
}



