﻿namespace Empresa
{
    partial class FrmBorrar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnBorrarAeropuerto = new System.Windows.Forms.Button();
            this.btnBorrarAerolinea = new System.Windows.Forms.Button();
            this.btnBorrarVuelo = new System.Windows.Forms.Button();
            this.btnVolver = new System.Windows.Forms.Button();
            this.comboAeropuerto = new System.Windows.Forms.ComboBox();
            this.comboAerolinea = new System.Windows.Forms.ComboBox();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.comboAeropuerto2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboAerolinea2 = new System.Windows.Forms.ComboBox();
            this.btnBorrarAerolineaSegunAeropuerto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(91, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 24);
            this.label1.TabIndex = 20;
            this.label1.Text = "Aeropuerto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(91, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 24);
            this.label2.TabIndex = 22;
            this.label2.Text = "Aerolinea";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(91, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 24);
            this.label3.TabIndex = 24;
            this.label3.Text = "Nº Vuelo";
            // 
            // btnBorrarAeropuerto
            // 
            this.btnBorrarAeropuerto.Location = new System.Drawing.Point(413, 60);
            this.btnBorrarAeropuerto.Name = "btnBorrarAeropuerto";
            this.btnBorrarAeropuerto.Size = new System.Drawing.Size(111, 21);
            this.btnBorrarAeropuerto.TabIndex = 2;
            this.btnBorrarAeropuerto.Text = "Borrar";
            this.btnBorrarAeropuerto.UseVisualStyleBackColor = true;
            this.btnBorrarAeropuerto.Click += new System.EventHandler(this.btnBorrarAeropuerto_Click);
            // 
            // btnBorrarAerolinea
            // 
            this.btnBorrarAerolinea.Location = new System.Drawing.Point(413, 123);
            this.btnBorrarAerolinea.Name = "btnBorrarAerolinea";
            this.btnBorrarAerolinea.Size = new System.Drawing.Size(111, 21);
            this.btnBorrarAerolinea.TabIndex = 4;
            this.btnBorrarAerolinea.Text = "Borrar";
            this.btnBorrarAerolinea.UseVisualStyleBackColor = true;
            this.btnBorrarAerolinea.Click += new System.EventHandler(this.btnBorrarAerolinea_Click);
            // 
            // btnBorrarVuelo
            // 
            this.btnBorrarVuelo.Location = new System.Drawing.Point(413, 193);
            this.btnBorrarVuelo.Name = "btnBorrarVuelo";
            this.btnBorrarVuelo.Size = new System.Drawing.Size(111, 25);
            this.btnBorrarVuelo.TabIndex = 6;
            this.btnBorrarVuelo.Text = "Borrar";
            this.btnBorrarVuelo.UseVisualStyleBackColor = true;
            this.btnBorrarVuelo.Click += new System.EventHandler(this.btnBorrarVuelo_Click);
            // 
            // btnVolver
            // 
            this.btnVolver.Location = new System.Drawing.Point(528, 323);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(111, 34);
            this.btnVolver.TabIndex = 7;
            this.btnVolver.Text = "Volver";
            this.btnVolver.UseVisualStyleBackColor = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // comboAeropuerto
            // 
            this.comboAeropuerto.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.comboAeropuerto.FormattingEnabled = true;
            this.comboAeropuerto.Location = new System.Drawing.Point(95, 60);
            this.comboAeropuerto.Name = "comboAeropuerto";
            this.comboAeropuerto.Size = new System.Drawing.Size(298, 21);
            this.comboAeropuerto.TabIndex = 1;
            // 
            // comboAerolinea
            // 
            this.comboAerolinea.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.comboAerolinea.FormattingEnabled = true;
            this.comboAerolinea.Location = new System.Drawing.Point(95, 123);
            this.comboAerolinea.Name = "comboAerolinea";
            this.comboAerolinea.Size = new System.Drawing.Size(298, 21);
            this.comboAerolinea.TabIndex = 3;
            // 
            // txtNumero
            // 
            this.txtNumero.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNumero.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumero.Location = new System.Drawing.Point(95, 194);
            this.txtNumero.Multiline = true;
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(298, 24);
            this.txtNumero.TabIndex = 5;
            // 
            // comboAeropuerto2
            // 
            this.comboAeropuerto2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.comboAeropuerto2.FormattingEnabled = true;
            this.comboAeropuerto2.Location = new System.Drawing.Point(95, 270);
            this.comboAeropuerto2.Name = "comboAeropuerto2";
            this.comboAeropuerto2.Size = new System.Drawing.Size(132, 21);
            this.comboAeropuerto2.TabIndex = 25;
            this.comboAeropuerto2.SelectedIndexChanged += new System.EventHandler(this.comboAeropuerto2_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(91, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 24);
            this.label4.TabIndex = 26;
            this.label4.Text = "Aeropuerto";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(263, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 24);
            this.label5.TabIndex = 28;
            this.label5.Text = "Aerolinea";
            // 
            // comboAerolinea2
            // 
            this.comboAerolinea2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.comboAerolinea2.FormattingEnabled = true;
            this.comboAerolinea2.Location = new System.Drawing.Point(267, 270);
            this.comboAerolinea2.Name = "comboAerolinea2";
            this.comboAerolinea2.Size = new System.Drawing.Size(126, 21);
            this.comboAerolinea2.TabIndex = 29;
            // 
            // btnBorrarAerolineaSegunAeropuerto
            // 
            this.btnBorrarAerolineaSegunAeropuerto.Location = new System.Drawing.Point(413, 243);
            this.btnBorrarAerolineaSegunAeropuerto.Name = "btnBorrarAerolineaSegunAeropuerto";
            this.btnBorrarAerolineaSegunAeropuerto.Size = new System.Drawing.Size(111, 48);
            this.btnBorrarAerolineaSegunAeropuerto.TabIndex = 30;
            this.btnBorrarAerolineaSegunAeropuerto.Text = "Borrar";
            this.btnBorrarAerolineaSegunAeropuerto.UseVisualStyleBackColor = true;
            this.btnBorrarAerolineaSegunAeropuerto.Click += new System.EventHandler(this.btnBorrarAerolineaSegunAeropuerto_Click);
            // 
            // FrmBorrar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(651, 369);
            this.ControlBox = false;
            this.Controls.Add(this.btnBorrarAerolineaSegunAeropuerto);
            this.Controls.Add(this.comboAerolinea2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboAeropuerto2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.comboAerolinea);
            this.Controls.Add(this.comboAeropuerto);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.btnBorrarVuelo);
            this.Controls.Add(this.btnBorrarAerolinea);
            this.Controls.Add(this.btnBorrarAeropuerto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FrmBorrar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Borrar";
            this.Load += new System.EventHandler(this.FrmBorrar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnBorrarAeropuerto;
        private System.Windows.Forms.Button btnBorrarAerolinea;
        private System.Windows.Forms.Button btnBorrarVuelo;
        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.ComboBox comboAeropuerto;
        private System.Windows.Forms.ComboBox comboAerolinea;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.ComboBox comboAeropuerto2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboAerolinea2;
        private System.Windows.Forms.Button btnBorrarAerolineaSegunAeropuerto;
    }
}