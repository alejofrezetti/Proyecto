﻿namespace Empresa
{
    partial class FrmVerVuelos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVolver = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.labelAeropuerto = new System.Windows.Forms.Label();
            this.labelAsientosTotales = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.labelHora = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.labelFecha = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelAerolinea = new System.Windows.Forms.Label();
            this.labelOrigen = new System.Windows.Forms.Label();
            this.labelPrecio = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelAsientosDisponibles = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnVerPasajeros = new System.Windows.Forms.Button();
            this.labelDestino = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnVolver
            // 
            this.btnVolver.Location = new System.Drawing.Point(713, 448);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(111, 34);
            this.btnVolver.TabIndex = 17;
            this.btnVolver.Text = "Volver";
            this.btnVolver.UseVisualStyleBackColor = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(362, 105);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(111, 34);
            this.btnBuscar.TabIndex = 16;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // txtNumero
            // 
            this.txtNumero.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNumero.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumero.Location = new System.Drawing.Point(269, 58);
            this.txtNumero.Multiline = true;
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(298, 30);
            this.txtNumero.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(320, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 24);
            this.label1.TabIndex = 18;
            this.label1.Text = "Numero de Vuelo";
            // 
            // labelAeropuerto
            // 
            this.labelAeropuerto.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelAeropuerto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAeropuerto.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAeropuerto.Location = new System.Drawing.Point(571, 319);
            this.labelAeropuerto.Name = "labelAeropuerto";
            this.labelAeropuerto.Size = new System.Drawing.Size(182, 24);
            this.labelAeropuerto.TabIndex = 75;
            // 
            // labelAsientosTotales
            // 
            this.labelAsientosTotales.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelAsientosTotales.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAsientosTotales.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAsientosTotales.Location = new System.Drawing.Point(245, 319);
            this.labelAsientosTotales.Name = "labelAsientosTotales";
            this.labelAsientosTotales.Size = new System.Drawing.Size(182, 24);
            this.labelAsientosTotales.TabIndex = 74;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label16.Location = new System.Drawing.Point(439, 321);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(123, 24);
            this.label16.TabIndex = 73;
            this.label16.Text = "Aeropuerto";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label17.Location = new System.Drawing.Point(61, 321);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(178, 24);
            this.label17.TabIndex = 72;
            this.label17.Text = "Asientos Totales";
            // 
            // labelHora
            // 
            this.labelHora.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelHora.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelHora.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHora.Location = new System.Drawing.Point(571, 223);
            this.labelHora.Name = "labelHora";
            this.labelHora.Size = new System.Drawing.Size(182, 24);
            this.labelHora.TabIndex = 71;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label13.Location = new System.Drawing.Point(502, 223);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 24);
            this.label13.TabIndex = 70;
            this.label13.Text = "Hora";
            // 
            // labelFecha
            // 
            this.labelFecha.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelFecha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelFecha.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFecha.Location = new System.Drawing.Point(571, 174);
            this.labelFecha.Name = "labelFecha";
            this.labelFecha.Size = new System.Drawing.Size(182, 24);
            this.labelFecha.TabIndex = 69;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Location = new System.Drawing.Point(491, 174);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 24);
            this.label11.TabIndex = 68;
            this.label11.Text = "Fecha";
            // 
            // labelAerolinea
            // 
            this.labelAerolinea.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelAerolinea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAerolinea.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAerolinea.Location = new System.Drawing.Point(571, 269);
            this.labelAerolinea.Name = "labelAerolinea";
            this.labelAerolinea.Size = new System.Drawing.Size(182, 24);
            this.labelAerolinea.TabIndex = 67;
            // 
            // labelOrigen
            // 
            this.labelOrigen.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelOrigen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelOrigen.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOrigen.Location = new System.Drawing.Point(245, 223);
            this.labelOrigen.Name = "labelOrigen";
            this.labelOrigen.Size = new System.Drawing.Size(182, 24);
            this.labelOrigen.TabIndex = 66;
            // 
            // labelPrecio
            // 
            this.labelPrecio.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelPrecio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelPrecio.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPrecio.Location = new System.Drawing.Point(245, 176);
            this.labelPrecio.Name = "labelPrecio";
            this.labelPrecio.Size = new System.Drawing.Size(182, 24);
            this.labelPrecio.TabIndex = 65;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(167, 176);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 24);
            this.label7.TabIndex = 64;
            this.label7.Text = "Precio";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(457, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 24);
            this.label2.TabIndex = 61;
            this.label2.Text = "Aerolinea";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(161, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 24);
            this.label4.TabIndex = 60;
            this.label4.Text = "Origen";
            // 
            // labelAsientosDisponibles
            // 
            this.labelAsientosDisponibles.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelAsientosDisponibles.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAsientosDisponibles.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAsientosDisponibles.Location = new System.Drawing.Point(245, 366);
            this.labelAsientosDisponibles.Name = "labelAsientosDisponibles";
            this.labelAsientosDisponibles.Size = new System.Drawing.Size(182, 24);
            this.labelAsientosDisponibles.TabIndex = 77;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(15, 365);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(224, 24);
            this.label5.TabIndex = 76;
            this.label5.Text = "Asientos Disponibles";
            // 
            // btnVerPasajeros
            // 
            this.btnVerPasajeros.Location = new System.Drawing.Point(571, 365);
            this.btnVerPasajeros.Name = "btnVerPasajeros";
            this.btnVerPasajeros.Size = new System.Drawing.Size(111, 34);
            this.btnVerPasajeros.TabIndex = 78;
            this.btnVerPasajeros.Text = "Ver Pasajeros";
            this.btnVerPasajeros.UseVisualStyleBackColor = true;
            this.btnVerPasajeros.Click += new System.EventHandler(this.btnVerPasajeros_Click);
            // 
            // labelDestino
            // 
            this.labelDestino.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelDestino.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDestino.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDestino.Location = new System.Drawing.Point(245, 271);
            this.labelDestino.Name = "labelDestino";
            this.labelDestino.Size = new System.Drawing.Size(182, 24);
            this.labelDestino.TabIndex = 80;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(150, 273);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 24);
            this.label6.TabIndex = 79;
            this.label6.Text = "Destino";
            // 
            // FrmVerVuelos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(839, 498);
            this.ControlBox = false;
            this.Controls.Add(this.labelDestino);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnVerPasajeros);
            this.Controls.Add(this.labelAsientosDisponibles);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelAeropuerto);
            this.Controls.Add(this.labelAsientosTotales);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.labelHora);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.labelFecha);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.labelAerolinea);
            this.Controls.Add(this.labelOrigen);
            this.Controls.Add(this.labelPrecio);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.label1);
            this.Name = "FrmVerVuelos";
            this.Text = "FrmVerVuelos";
            this.Load += new System.EventHandler(this.FrmVerVuelos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelAeropuerto;
        private System.Windows.Forms.Label labelAsientosTotales;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label labelHora;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labelFecha;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelAerolinea;
        private System.Windows.Forms.Label labelOrigen;
        private System.Windows.Forms.Label labelPrecio;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelAsientosDisponibles;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnVerPasajeros;
        private System.Windows.Forms.Label labelDestino;
        private System.Windows.Forms.Label label6;
    }
}