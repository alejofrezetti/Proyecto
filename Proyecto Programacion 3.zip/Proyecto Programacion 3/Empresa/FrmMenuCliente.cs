﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmMenuCliente : Form
    {
        private FrmLogin frmLogin;
        private FrmVerificarVuelo frmVerificarVuelo;
        private FrmBuscarVuelos frmBuscarVuelos;
        public FrmMenuCliente(FrmLogin _frmLogin)
        {
            InitializeComponent();
            frmLogin = _frmLogin;

            frmVerificarVuelo = new FrmVerificarVuelo(this);
            frmBuscarVuelos = new FrmBuscarVuelos(this);
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            frmLogin.Show();
            this.Hide();
        }

        private void FrmMenuCliente_Load(object sender, EventArgs e)
        {

        }

        private void btnBuscarVuelos_Click(object sender, EventArgs e)
        {
            frmBuscarVuelos.Show();
            this.Hide();       
        }

        private void btnVerificarVuelo_Click(object sender, EventArgs e)
        {
            frmVerificarVuelo = new FrmVerificarVuelo(this);
            if (Program.UsuarioActual.vuelo != null)
            {
                frmVerificarVuelo.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("No tiene reservas a su nombre");
                return;
            }            
        }
    }
}

                            

                  