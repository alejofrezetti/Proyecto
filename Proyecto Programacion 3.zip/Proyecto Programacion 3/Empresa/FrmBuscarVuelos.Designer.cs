﻿namespace Empresa
{
    partial class FrmBuscarVuelos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboDestino = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.labelNumero = new System.Windows.Forms.Label();
            this.labelPrecio = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.labelOrigen = new System.Windows.Forms.Label();
            this.labelAerolinea = new System.Windows.Forms.Label();
            this.btnReservar = new System.Windows.Forms.Button();
            this.btnVolver = new System.Windows.Forms.Button();
            this.btnAnterior = new System.Windows.Forms.Button();
            this.labelFecha = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelHora = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.labelAeropuerto = new System.Windows.Forms.Label();
            this.labelAsientos = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.cancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // comboDestino
            // 
            this.comboDestino.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.comboDestino.FormattingEnabled = true;
            this.comboDestino.ItemHeight = 13;
            this.comboDestino.Location = new System.Drawing.Point(197, 48);
            this.comboDestino.Name = "comboDestino";
            this.comboDestino.Size = new System.Drawing.Size(310, 21);
            this.comboDestino.TabIndex = 1;
            this.comboDestino.SelectedIndexChanged += new System.EventHandler(this.comboDestino_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(193, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 24);
            this.label5.TabIndex = 36;
            this.label5.Text = "Destino";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(358, 239);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 24);
            this.label2.TabIndex = 40;
            this.label2.Text = "Aerolinea";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 239);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 24);
            this.label1.TabIndex = 38;
            this.label1.Text = "Origen";
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(197, 75);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(310, 43);
            this.btnBuscar.TabIndex = 2;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 24);
            this.label3.TabIndex = 42;
            this.label3.Text = "Nº de vuelo";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // labelNumero
            // 
            this.labelNumero.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelNumero.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelNumero.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumero.Location = new System.Drawing.Point(144, 141);
            this.labelNumero.Name = "labelNumero";
            this.labelNumero.Size = new System.Drawing.Size(182, 24);
            this.labelNumero.TabIndex = 43;
            // 
            // labelPrecio
            // 
            this.labelPrecio.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelPrecio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelPrecio.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPrecio.Location = new System.Drawing.Point(144, 191);
            this.labelPrecio.Name = "labelPrecio";
            this.labelPrecio.Size = new System.Drawing.Size(182, 24);
            this.labelPrecio.TabIndex = 45;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(66, 191);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 24);
            this.label7.TabIndex = 44;
            this.label7.Text = "Precio";
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.Location = new System.Drawing.Point(396, 339);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(111, 34);
            this.btnSiguiente.TabIndex = 4;
            this.btnSiguiente.Text = "Proximo Vuelo";
            this.btnSiguiente.UseVisualStyleBackColor = true;
            this.btnSiguiente.Click += new System.EventHandler(this.btnSiguiente_Click);
            // 
            // labelOrigen
            // 
            this.labelOrigen.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelOrigen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelOrigen.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOrigen.Location = new System.Drawing.Point(144, 238);
            this.labelOrigen.Name = "labelOrigen";
            this.labelOrigen.Size = new System.Drawing.Size(182, 24);
            this.labelOrigen.TabIndex = 47;
            // 
            // labelAerolinea
            // 
            this.labelAerolinea.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelAerolinea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAerolinea.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAerolinea.Location = new System.Drawing.Point(472, 237);
            this.labelAerolinea.Name = "labelAerolinea";
            this.labelAerolinea.Size = new System.Drawing.Size(182, 24);
            this.labelAerolinea.TabIndex = 48;
            // 
            // btnReservar
            // 
            this.btnReservar.Location = new System.Drawing.Point(314, 382);
            this.btnReservar.Name = "btnReservar";
            this.btnReservar.Size = new System.Drawing.Size(103, 66);
            this.btnReservar.TabIndex = 5;
            this.btnReservar.Text = "Reservar";
            this.btnReservar.UseVisualStyleBackColor = true;
            this.btnReservar.Click += new System.EventHandler(this.btnReservar_Click);
            // 
            // btnVolver
            // 
            this.btnVolver.Location = new System.Drawing.Point(543, 411);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(111, 34);
            this.btnVolver.TabIndex = 6;
            this.btnVolver.Text = "Volver";
            this.btnVolver.UseVisualStyleBackColor = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // btnAnterior
            // 
            this.btnAnterior.Location = new System.Drawing.Point(220, 339);
            this.btnAnterior.Name = "btnAnterior";
            this.btnAnterior.Size = new System.Drawing.Size(111, 34);
            this.btnAnterior.TabIndex = 3;
            this.btnAnterior.Text = "Vuelo Anterior";
            this.btnAnterior.UseVisualStyleBackColor = true;
            this.btnAnterior.Click += new System.EventHandler(this.btnAnterior_Click);
            // 
            // labelFecha
            // 
            this.labelFecha.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelFecha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelFecha.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFecha.Location = new System.Drawing.Point(472, 142);
            this.labelFecha.Name = "labelFecha";
            this.labelFecha.Size = new System.Drawing.Size(182, 24);
            this.labelFecha.TabIndex = 53;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(392, 142);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 24);
            this.label11.TabIndex = 52;
            this.label11.Text = "Fecha";
            // 
            // labelHora
            // 
            this.labelHora.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelHora.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelHora.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHora.Location = new System.Drawing.Point(472, 191);
            this.labelHora.Name = "labelHora";
            this.labelHora.Size = new System.Drawing.Size(182, 24);
            this.labelHora.TabIndex = 55;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(403, 191);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 24);
            this.label13.TabIndex = 54;
            this.label13.Text = "Hora";
            // 
            // labelAeropuerto
            // 
            this.labelAeropuerto.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelAeropuerto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAeropuerto.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAeropuerto.Location = new System.Drawing.Point(472, 287);
            this.labelAeropuerto.Name = "labelAeropuerto";
            this.labelAeropuerto.Size = new System.Drawing.Size(182, 24);
            this.labelAeropuerto.TabIndex = 59;
            // 
            // labelAsientos
            // 
            this.labelAsientos.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.labelAsientos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelAsientos.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAsientos.Location = new System.Drawing.Point(144, 288);
            this.labelAsientos.Name = "labelAsientos";
            this.labelAsientos.Size = new System.Drawing.Size(182, 24);
            this.labelAsientos.TabIndex = 58;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(340, 289);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(123, 24);
            this.label16.TabIndex = 57;
            this.label16.Text = "Aeropuerto";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(41, 289);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(97, 24);
            this.label17.TabIndex = 56;
            this.label17.Text = "Asientos";
            // 
            // cancelar
            // 
            this.cancelar.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.cancelar.Location = new System.Drawing.Point(12, 382);
            this.cancelar.Name = "cancelar";
            this.cancelar.Size = new System.Drawing.Size(126, 63);
            this.cancelar.TabIndex = 60;
            this.cancelar.Text = "Cancelar Reserva";
            this.cancelar.UseVisualStyleBackColor = false;
            this.cancelar.Click += new System.EventHandler(this.cancelar_Click);
            // 
            // FrmBuscarVuelos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(682, 460);
            this.ControlBox = false;
            this.Controls.Add(this.cancelar);
            this.Controls.Add(this.labelAeropuerto);
            this.Controls.Add(this.labelAsientos);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.labelHora);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.labelFecha);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnAnterior);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.btnReservar);
            this.Controls.Add(this.labelAerolinea);
            this.Controls.Add(this.labelOrigen);
            this.Controls.Add(this.btnSiguiente);
            this.Controls.Add(this.labelPrecio);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelNumero);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboDestino);
            this.Controls.Add(this.label5);
            this.Name = "FrmBuscarVuelos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Buscar Vuelos";
            this.Load += new System.EventHandler(this.FrmBuscarVuelos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboDestino;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelNumero;
        private System.Windows.Forms.Label labelPrecio;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSiguiente;
        private System.Windows.Forms.Label labelOrigen;
        private System.Windows.Forms.Label labelAerolinea;
        private System.Windows.Forms.Button btnReservar;
        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.Button btnAnterior;
        private System.Windows.Forms.Label labelFecha;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelHora;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labelAeropuerto;
        private System.Windows.Forms.Label labelAsientos;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button cancelar;
    }
}