﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
    
{
    [Serializable]
    public class Aerolinea
    {
        private List<Vuelo> vuelos;
        public string Nombre { get; set; }
        public List<Vuelo> Vuelos { get { return vuelos; } set { vuelos = value; } }

        public Aerolinea (string nombre) { 
            Nombre = nombre;
            vuelos = new List<Vuelo>();
        }

        public Vuelo BuscarVueloPorNumero(int _numero)
        {
            foreach (Vuelo vuelo in vuelos)
                if (vuelo.numero == _numero)
                    return vuelo;

            throw new VueloNoEncontrado();
        }

        public void AgregarVuelo(int Numero, string Origen, string Destino, double Precio,
            int AsientosTotales, int AsientosDisponibles, string Fecha, string Hora, string Aeropuerto, string Aerolinea)
        {
            vuelos.Add(new Vuelo(Numero, Origen, Destino, Precio, AsientosTotales, AsientosDisponibles, Fecha, Hora, Aeropuerto, Aerolinea));
            
        }

        public bool ContieneElVuelo(int _numero)
        {
            foreach (Vuelo vuelo in vuelos)
                if (vuelo.numero == _numero)
                    return true;
            return false;
        }


    }
}
