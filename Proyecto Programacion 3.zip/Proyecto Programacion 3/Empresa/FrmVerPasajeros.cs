﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmVerPasajeros : Form
    {
        private FrmVerVuelos frmVerVuelos;
        private Vuelo vueloParaVer;
        public FrmVerPasajeros(FrmVerVuelos _frmVerVuelo, Vuelo _vueloParaVer)
        {
            InitializeComponent();
            frmVerVuelos = _frmVerVuelo;
            vueloParaVer = _vueloParaVer;
        }

        private void FrmVerPasajeros_Load(object sender, EventArgs e)
        {
            labelPasajeros.Text = "";

            if (vueloParaVer != null)
            {
                foreach (Usuario pasajero in vueloParaVer.Pasajeros)
                    labelPasajeros.Text += "\nNombre: " + pasajero.nombre +
                                           " / DNI: " + pasajero.dni;
            }
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            frmVerVuelos.Show();
            this.Hide();
        }

        private void labelPasajeros_Click(object sender, EventArgs e)
        {

        }
    }
}
