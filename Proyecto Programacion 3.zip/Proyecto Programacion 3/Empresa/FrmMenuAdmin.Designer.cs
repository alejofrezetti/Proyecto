﻿namespace Empresa
{
    partial class FrmMenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.btnAgregarVuelo = new System.Windows.Forms.Button();
            this.btnAgregarAerolinea = new System.Windows.Forms.Button();
            this.btnBorrar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAgregarAeropuerto = new System.Windows.Forms.Button();
            this.btnVerUsuarios = new System.Windows.Forms.Button();
            this.btnVerVuelos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.Location = new System.Drawing.Point(478, 405);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(111, 34);
            this.btnCerrarSesion.TabIndex = 5;
            this.btnCerrarSesion.Text = "Cerrar Sesion";
            this.btnCerrarSesion.UseVisualStyleBackColor = true;
            this.btnCerrarSesion.Click += new System.EventHandler(this.btnCerrarSesion_Click);
            // 
            // btnAgregarVuelo
            // 
            this.btnAgregarVuelo.Location = new System.Drawing.Point(62, 251);
            this.btnAgregarVuelo.Name = "btnAgregarVuelo";
            this.btnAgregarVuelo.Size = new System.Drawing.Size(210, 92);
            this.btnAgregarVuelo.TabIndex = 3;
            this.btnAgregarVuelo.Text = "Agregar Vuelo";
            this.btnAgregarVuelo.UseVisualStyleBackColor = true;
            this.btnAgregarVuelo.Click += new System.EventHandler(this.btnAgregarVuelo_Click);
            // 
            // btnAgregarAerolinea
            // 
            this.btnAgregarAerolinea.Location = new System.Drawing.Point(335, 111);
            this.btnAgregarAerolinea.Name = "btnAgregarAerolinea";
            this.btnAgregarAerolinea.Size = new System.Drawing.Size(210, 92);
            this.btnAgregarAerolinea.TabIndex = 2;
            this.btnAgregarAerolinea.Text = "Agregar Aerolinea";
            this.btnAgregarAerolinea.UseVisualStyleBackColor = true;
            this.btnAgregarAerolinea.Click += new System.EventHandler(this.btnAgregarAerolinea_Click);
            // 
            // btnBorrar
            // 
            this.btnBorrar.Location = new System.Drawing.Point(335, 251);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(210, 92);
            this.btnBorrar.TabIndex = 4;
            this.btnBorrar.Text = "Borrar";
            this.btnBorrar.UseVisualStyleBackColor = true;
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(119, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(363, 58);
            this.label1.TabIndex = 13;
            this.label1.Text = "Administrador";
            // 
            // btnAgregarAeropuerto
            // 
            this.btnAgregarAeropuerto.Location = new System.Drawing.Point(62, 111);
            this.btnAgregarAeropuerto.Name = "btnAgregarAeropuerto";
            this.btnAgregarAeropuerto.Size = new System.Drawing.Size(210, 92);
            this.btnAgregarAeropuerto.TabIndex = 1;
            this.btnAgregarAeropuerto.Text = "Agregar Aeropuerto";
            this.btnAgregarAeropuerto.UseVisualStyleBackColor = true;
            this.btnAgregarAeropuerto.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnVerUsuarios
            // 
            this.btnVerUsuarios.Location = new System.Drawing.Point(21, 404);
            this.btnVerUsuarios.Name = "btnVerUsuarios";
            this.btnVerUsuarios.Size = new System.Drawing.Size(111, 34);
            this.btnVerUsuarios.TabIndex = 14;
            this.btnVerUsuarios.Text = "Ver Usuarios";
            this.btnVerUsuarios.UseVisualStyleBackColor = true;
            this.btnVerUsuarios.Click += new System.EventHandler(this.btnVerUsuarios_Click);
            // 
            // btnVerVuelos
            // 
            this.btnVerVuelos.Location = new System.Drawing.Point(161, 404);
            this.btnVerVuelos.Name = "btnVerVuelos";
            this.btnVerVuelos.Size = new System.Drawing.Size(111, 34);
            this.btnVerVuelos.TabIndex = 15;
            this.btnVerVuelos.Text = "Ver Vuelos";
            this.btnVerVuelos.UseVisualStyleBackColor = true;
            this.btnVerVuelos.Click += new System.EventHandler(this.btnVerVuelos_Click);
            // 
            // FrmMenuAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(616, 450);
            this.ControlBox = false;
            this.Controls.Add(this.btnVerVuelos);
            this.Controls.Add(this.btnVerUsuarios);
            this.Controls.Add(this.btnCerrarSesion);
            this.Controls.Add(this.btnAgregarVuelo);
            this.Controls.Add(this.btnAgregarAerolinea);
            this.Controls.Add(this.btnBorrar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAgregarAeropuerto);
            this.Name = "FrmMenuAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Admin";
            this.Load += new System.EventHandler(this.FrmMenuAdmin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.Button btnAgregarVuelo;
        private System.Windows.Forms.Button btnAgregarAerolinea;
        private System.Windows.Forms.Button btnBorrar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAgregarAeropuerto;
        private System.Windows.Forms.Button btnVerUsuarios;
        private System.Windows.Forms.Button btnVerVuelos;
    }
}