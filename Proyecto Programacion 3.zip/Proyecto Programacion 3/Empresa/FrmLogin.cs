﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Empresa
{
    [Serializable]
    public partial class FrmLogin : Form
    {
        private FrmCrearCuenta frmCrearCuenta;
        private FrmMenuAdmin frmMenuAdmin;
        private FrmMenuCliente frmMenuCliente;
        
        
        
        public FrmLogin()
        {
            InitializeComponent();
            frmCrearCuenta = new FrmCrearCuenta(this);
            frmMenuAdmin = new FrmMenuAdmin(this);
            frmMenuCliente = new FrmMenuCliente(this);
                       
        }

        private void login_Load(object sender, EventArgs e)
        {
            
            
            if (!File.Exists("Datos.bin"))
            {
                Stream flujo = File.Create("Datos.bin");
                BinaryFormatter serializer = new BinaryFormatter();
                serializer.Serialize(flujo, Program.Empresa);
                flujo.Close();
                //MessageBox.Show("No existe, lo creo");
            }
            else
            {
                
                Stream flujo1 = File.OpenRead("Datos.bin");
                BinaryFormatter deserializer = new BinaryFormatter();
                Program.Empresa = (MiEmpresa)deserializer.Deserialize(flujo1);
                flujo1.Close();
                //MessageBox.Show("ya existe, lo cargo");
            }

            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Stream flujo1 = File.OpenRead("Usuarios.bin");
            //BinaryFormatter deserializer = new BinaryFormatter();
            //MiEmpresa.Usuarios = (List<Usuario>)deserializer.Deserialize(flujo1);

            bool encontrado = false;
           
            

            foreach (Usuario u in Program.Empresa.Usuarios)
            {
                if(u.nombre == txtUsuario.Text && u.contrasena == txtContrasena.Text)
                {
                    encontrado = true;
                    Program.UsuarioActual = u;
                    if (u.esAdmin == true) { frmMenuAdmin.Show(); this.Hide();  }
                    else { frmMenuCliente.Show(); this.Hide(); }
                    break;
                }
            }

            if (!encontrado)
            {
                MessageBox.Show("Usuario y/o Contraseña incorrectos");
            }
            txtContrasena.Text = "";
            // flujo1.Close();
        }

        private void btnCrearCuenta_Click(object sender, EventArgs e)
        {
            txtContrasena.Text = "";
            frmCrearCuenta.Show();
            this.Hide();
        }

        private void FrmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        private void txtContrasena_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
