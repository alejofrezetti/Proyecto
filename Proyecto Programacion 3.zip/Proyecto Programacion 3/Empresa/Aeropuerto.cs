﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    [Serializable]
    public class Aeropuerto
    {

        private List<Aerolinea> aerolineas;
        public string nombre { get; set; }
        public List<Aerolinea> Aerolineas { get { return aerolineas; } set { aerolineas = value; } }
        
        public Aeropuerto(string Nombre) { 
            nombre = Nombre;
            aerolineas = new List<Aerolinea>();
        }

        public Aerolinea BuscarAerolineaPorNombre(string _nombre)
        {
            foreach (Aerolinea aerolinea in aerolineas)
                if (aerolinea.Nombre == _nombre)
                    return aerolinea;

            throw new AerolineaNoEncontrada();
            
        }

        public bool ContieneLaAerolinea(string _nombre)
        {
            foreach (Aerolinea aerolinea in aerolineas)
                if (aerolinea.Nombre == _nombre)
                    return true;
            return false;
        }



    }
}
