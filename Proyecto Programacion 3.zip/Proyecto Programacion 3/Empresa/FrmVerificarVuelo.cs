﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmVerificarVuelo : Form
    {
        private FrmMenuCliente frmMenuCliente;   
        
        
        public FrmVerificarVuelo(FrmMenuCliente _frmMenuCliente)
        {
            InitializeComponent();
            frmMenuCliente = _frmMenuCliente;
        }
        private void FrmVerificarVuelo_Load(object sender, EventArgs e)
        {               
            LimpiarLabels();
            labelNumero.Text = Program.UsuarioActual.vuelo.numero.ToString();
            labelPrecio.Text = Program.UsuarioActual.vuelo.precio.ToString();
            labelOrigen.Text = Program.UsuarioActual.vuelo.origen;
            labelDestino.Text = Program.UsuarioActual.vuelo.destino;
            labelAerolinea.Text = Program.UsuarioActual.vuelo.aerolinea;
            labelAeropuerto.Text = Program.UsuarioActual.vuelo.aeropuerto;
            labelFecha.Text = Program.UsuarioActual.vuelo.fecha;
            labelHora.Text = Program.UsuarioActual.vuelo.hora; 
        }
        private void btnVolver_Click(object sender, EventArgs e)
        {                     
            frmMenuCliente.Show();
            this.Hide();
            LimpiarLabels();
        }
        private void LimpiarLabels()
        {           
            labelNumero.Text = "";
            labelPrecio.Text = "";
            labelOrigen.Text = "";
            labelDestino.Text = "";
            labelAerolinea.Text = "";
            labelAeropuerto.Text = ""; 
            labelFecha.Text = "";
            labelHora.Text = "";            
        }
        private void reservas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }        
    }
}
