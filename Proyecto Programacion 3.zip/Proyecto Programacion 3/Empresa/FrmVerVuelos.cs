﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmVerVuelos : Form
    {
        private FrmMenuAdmin frmMenuAdmin;
        private FrmVerPasajeros frmVerPasajeros;
        private Vuelo vueloBuscado;
        public FrmVerVuelos( FrmMenuAdmin _frmMenuAdmin)
        {
            InitializeComponent();
            frmMenuAdmin = _frmMenuAdmin;
        }

        private void FrmVerVuelos_Load(object sender, EventArgs e)
        {

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            LimpiarLabels();
            frmMenuAdmin.Show();
            this.Hide();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            LimpiarLabels();
            vueloBuscado = null;

            if (txtNumero.Text != "")
            {
                foreach (Aeropuerto aeropuerto in Program.Empresa.Aeropuertos)
                    foreach (Aerolinea aerolinea in aeropuerto.Aerolineas)
                        if (aerolinea.ContieneElVuelo(Int32.Parse(txtNumero.Text)))
                            vueloBuscado = aerolinea.BuscarVueloPorNumero(Int32.Parse(txtNumero.Text));

                if (vueloBuscado == null) MessageBox.Show("No se encontro el vuelo");
                else
                {
                    labelAerolinea.Text = vueloBuscado.aerolinea;
                    labelAeropuerto.Text = vueloBuscado.aeropuerto;
                    labelAsientosTotales.Text = vueloBuscado.asientosTotales.ToString();
                    labelAsientosDisponibles.Text = vueloBuscado.asientosDisponibles.ToString();
                    labelFecha.Text = vueloBuscado.fecha;
                    labelHora.Text = vueloBuscado.hora;
                    labelOrigen.Text = vueloBuscado.origen;
                    labelDestino.Text = vueloBuscado.destino;
                    labelPrecio.Text = vueloBuscado.precio.ToString();

                }

            }
            else MessageBox.Show("Ingrese numero de vuelo");

            frmVerPasajeros = new FrmVerPasajeros(this, vueloBuscado);
        }

        private void btnVerPasajeros_Click(object sender, EventArgs e)
        {
            if (vueloBuscado != null)
                {
                    frmVerPasajeros.Show();
                    this.Hide();
                }
            else   MessageBox.Show("Por favor realice una busqueda");
                          
        }

        public void LimpiarLabels()
        {
            labelAerolinea.Text = "";
            labelAeropuerto.Text = "";
            labelAsientosTotales.Text = "";
            labelAsientosDisponibles.Text = "";
            labelFecha.Text = "";
            labelHora.Text = "";
            labelOrigen.Text = "";
            labelDestino.Text = "";
            labelPrecio.Text = "";
        }
    }
}
