﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    public partial class FrmAgregarAeropuerto : Form
    {
        private FrmMenuAdmin frmMenuAdmin;
        public FrmAgregarAeropuerto(FrmMenuAdmin _frmMenuAdmin)
        {
            InitializeComponent();
            frmMenuAdmin = _frmMenuAdmin;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmMenuAdmin.Show();
            this.Hide();
        }

        private void FrmAgregarAeropuerto_Load(object sender, EventArgs e)
        {
            
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNombre.Text != "")
                {
                    Program.Empresa.BuscarAeropuertoPorNombre(txtNombre.Text);
                    MessageBox.Show("El aeropuerto ya existe");
                }
                else
                    MessageBox.Show("Por favor complete el Nombre");
                
            }
            catch (AeropuertoNoEncontrado) {
                Program.Empresa.Aeropuertos.Add(new Aeropuerto(txtNombre.Text));
                MessageBox.Show("¡Agregado correctamente!");
                txtNombre.Clear();
            }
            
            
            
             
            
        }
    }
}
