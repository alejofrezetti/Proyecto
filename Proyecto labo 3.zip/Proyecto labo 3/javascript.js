"use strict"

document.getElementById("total").innerHTML = 100;
document.getElementById("correctas").innerHTML = 0;

			
document.getElementById("formu").onsubmit = function() 
{
	LimpiarRespuestas();

	var puntajeObtenido = 0;
	var i;
	var formu = document.getElementById("formu");
	var cont = 0;
	

	//EJERCICIO 1---------------------------------------------------------------

	var palabrasClavePregunta1 = [ "De la Rua", "De la Rúa", "de La Rua", "de La Rúa" , "Duhalde", "Rodriguez Saá", "Rodriguez Saa", "Camaño", "Puerta" ];
	var palabrasClavePregunta2 = [ "Boca", "Esófago", "Esofago", "Estómago", "Estomago", "Intestino delgado", "Intestino grueso",
									 "Hígado" , "Higado" , "Páncreas" , "Pancreas", "Vesícula" , "Vesicula" , "Ano", "boca", "esófago", "esofago", "estómago",
									  "estomago", "intestino delgado", "intestino grueso", "hígado" , "higado" , "páncreas" , "pancreas", "vesícula" , "vesicula" , "ano" ];
	var palabrasClavePregunta3 = [ "Rojo", "Naranja", "Amarillo", "Verde", "Cian", "Azul", "Violeta", "rojo", "naranja", "amarillo", "verde", "cian", "azul", "violeta" ];
	var palabrasClavePregunta4 = [ "Neuquen", "Neuquén", "Río Negro", "Rio Negro", "Chubut", "Santa Cruz", "Tierra del Fuego", "Tierra del fuego"];
	var palabrasClavePregunta5 = [ "salida", "mar", "no", "contacto", "da", "ninguno", "No", "Ninguno", "sin", "Sin"]; //rta: No tienen salida al mar

	
	//PREGUNTA 1-----------------------------------
	var MinimoParaRegular = 2;
	var MinimoParaTic = 4;

	for(i=0;i<palabrasClavePregunta1.length;i++){
		if(formu.pregunta1.value.includes(palabrasClavePregunta1[i])) 
			cont++;
	}
	if(cont < MinimoParaRegular) document.getElementById("e1p1cruz").style.display = "inline";
	if(cont >= MinimoParaRegular && cont < MinimoParaTic ){ document.getElementById("e1p1reg").style.display = "inline"; puntajeObtenido+=4; }
	if(cont >= MinimoParaTic){ document.getElementById("e1p1tic").style.display = "inline"; puntajeObtenido+=8; }

	cont = 0;

	//PREGUNTA 2-----------------------------------

	MinimoParaRegular = 4;
	MinimoParaTic = 7;

	for(i=0;i<palabrasClavePregunta2.length;i++){
		if(formu.pregunta2.value.includes(palabrasClavePregunta2[i])) 
			cont++;
	}
	if(cont < MinimoParaRegular) document.getElementById("e1p2cruz").style.display = "inline";
	if(cont >= MinimoParaRegular && cont < MinimoParaTic ){ document.getElementById("e1p2reg").style.display = "inline"; puntajeObtenido+=4; }
	if(cont >= MinimoParaTic){ document.getElementById("e1p2tic").style.display = "inline"; puntajeObtenido+=8; }

	cont = 0;

	//PREGUNTA 3-----------------------------------

	MinimoParaRegular = 3;
	MinimoParaTic = 5; 
	
	for(i=0;i<palabrasClavePregunta3.length;i++){
		if(formu.pregunta3.value.includes(palabrasClavePregunta3[i])) 
			cont++;
	}
	if(cont < MinimoParaRegular) document.getElementById("e1p3cruz").style.display = "inline";
	if(cont >= MinimoParaRegular && cont < MinimoParaTic ){ document.getElementById("e1p3reg").style.display = "inline"; puntajeObtenido+=4; }
	if(cont >= MinimoParaTic){ document.getElementById("e1p3tic").style.display = "inline"; puntajeObtenido+=8; }

	cont = 0;

	//PREGUNTA 4-----------------------------------

	MinimoParaRegular = 2;
	MinimoParaTic = 4;

	for(i=0;i<palabrasClavePregunta4.length;i++){
		if(formu.pregunta4.value.includes(palabrasClavePregunta4[i])) 
			cont++;
	}
	if(cont < MinimoParaRegular) document.getElementById("e1p4cruz").style.display = "inline";
	if(cont >= MinimoParaRegular && cont < MinimoParaTic ){ document.getElementById("e1p4reg").style.display = "inline"; puntajeObtenido+=4; }
	if(cont >= MinimoParaTic){ document.getElementById("e1p4tic").style.display = "inline"; puntajeObtenido+=8; }

	cont = 0;

	//PREGUNTA 5-----------------------------------

	MinimoParaRegular = 3;
	MinimoParaTic = 3;

	for(i=0;i<palabrasClavePregunta5.length;i++){
		if(formu.pregunta5.value.includes(palabrasClavePregunta5[i])) 
			cont++;
	}
	if(cont < MinimoParaRegular) document.getElementById("e1p5cruz").style.display = "inline";
	//if(cont >= MinimoParaRegular && cont < MinimoParaTic ){ document.getElementById("e1p5reg").style.display = "block"; puntajeObtenido+=5; }
	if(cont >= MinimoParaTic){ document.getElementById("e1p5tic").style.display = "inline"; puntajeObtenido+=8; }

	//EJERCICIO 2 ---------------------------------------------------------------

	for(i=0 ; i<formu.e2p1.length ; i++){
		if(formu.e2p1[i].checked == true){
			if(formu.e2p1[i].value == "correcta"){
				puntajeObtenido+=10;
				document.getElementById("e2p1tic").style.display = "block";
				document.getElementById("e2p1cruz").style.display = "none";
			}
			else { 
				document.getElementById("e2p1cruz").style.display = "block"; 
			}
			break;
		}
		else { 
			document.getElementById("e2p1cruz").style.display = "block"; 
		}
		
	}

	for(i=0 ; i<formu.e2p2.length ; i++){
		if(formu.e2p2[i].checked == true){
			if(formu.e2p2[i].value == "correcta"){ 
				puntajeObtenido+=10;
				document.getElementById("e2p2tic").style.display = "block";
				document.getElementById("e2p2cruz").style.display = "none";
			}
			else{ document.getElementById("e2p2cruz").style.display = "block"; }
			break;
		}
		else{ document.getElementById("e2p2cruz").style.display = "block"; }
	}

	//EJERCICIO 3---------------------------------------------------------------

	cont = 0;
	for(i=0 ; i<formu.e3p1.length ; i++){
		if(formu.e3p1[i].checked == true){
			if(formu.e3p1[i].value == "correcta1" || formu.e3p1[i].value == "correcta2"){
				cont++;
			}
		}
	}

	

	if(cont==2) { document.getElementById("e3p1tic").style.display = "block"; puntajeObtenido+=10; }
	if(cont==1) { document.getElementById("e3p1reg").style.display = "block"; puntajeObtenido+=5;  }
	if(cont==0) document.getElementById("e3p1cruz").style.display = "block";

	cont = 0;

	for(i=0 ; i<formu.e3p2.length ; i++){
		if(formu.e3p2[i].checked == true){
			if(formu.e3p2[i].value == "correcta1" || formu.e3p2[i].value == "correcta2"){
				cont++;
			}
		}
	}

	if(cont==2) { document.getElementById("e3p2tic").style.display = "block"; puntajeObtenido+=10; }
	if(cont==1) { document.getElementById("e3p2reg").style.display = "block"; puntajeObtenido+=5;  }
	if(cont==0) document.getElementById("e3p2cruz").style.display = "block";

	cont = 0;
	
	// EJERCICIO 4---------------------------------------------------------------

	 // [0] = VERDADERO //
	//  [1] = FALSO    //

	if(formu.e4p1[0].checked){
		puntajeObtenido+=2;
		document.getElementById("e4p1tic").style.display = "inline";
	}
	else{ document.getElementById("e4p1cruz").style.display = "inline";}

	if(formu.e4p2[1].checked){
		puntajeObtenido+=2;
		document.getElementById("e4p2tic").style.display = "inline";
	}
	else{ document.getElementById("e4p2cruz").style.display = "inline";}

	if(formu.e4p3[1].checked){
		puntajeObtenido+=2;
		document.getElementById("e4p3tic").style.display = "inline";
	}
	else{ document.getElementById("e4p3cruz").style.display = "inline";}

	if(formu.e4p4[0].checked){
		puntajeObtenido+=2;
		document.getElementById("e4p4tic").style.display = "inline";
	}
	else{ document.getElementById("e4p4cruz").style.display = "inline";}

 	if(formu.e4p5[0].checked){
		puntajeObtenido+=2;
		document.getElementById("e4p5tic").style.display = "inline";
	}
	else{ document.getElementById("e4p5cruz").style.display = "inline";}

	// EJERCICIO 5---------------------------------------------------------------

	if (formu.e5p1.value == "Cachalote" || formu.e5p1.value == "cachalote" || formu.e5p1.value == "CACHALOTE"){
		document.getElementById("e5p1tic").style.display = "block";
		puntajeObtenido+=5;
	}
	else document.getElementById("e5p1cruz").style.display = "block";

	if (formu.e5p2.value == "el grito" || formu.e5p1.value == "El grito" || formu.e5p1.value == "EL GRITO"){
		document.getElementById("e5p2tic").style.display = "block";
		puntajeObtenido+=5;
	}
	else document.getElementById("e5p2cruz").style.display = "block";

	//formu.getElementbyClass("OpcionesCorrectas").style.color = green;


	// --------------------------------------------------------------------------
	
	document.getElementById("correctas").innerHTML = puntajeObtenido;

	MarcarCorrectas();
	return false;
}

function LimpiarRespuestas(){

	document.getElementById("e1p1tic").style.display  = "none";
	document.getElementById("e1p1reg").style.display  = "none";
	document.getElementById("e1p1cruz").style.display = "none";
	document.getElementById("e1p2tic").style.display  = "none";
	document.getElementById("e1p2reg").style.display  = "none";
	document.getElementById("e1p2cruz").style.display = "none";
	document.getElementById("e1p3tic").style.display  = "none";
	document.getElementById("e1p3reg").style.display  = "none";
	document.getElementById("e1p3cruz").style.display = "none";
	document.getElementById("e1p4tic").style.display  = "none";
	document.getElementById("e1p4reg").style.display  = "none";
	document.getElementById("e1p4cruz").style.display = "none";
	document.getElementById("e1p5tic").style.display  = "none";
	document.getElementById("e1p5reg").style.display  = "none";
	document.getElementById("e1p5cruz").style.display = "none";
	document.getElementById("e2p1tic").style.display  = "none";
	document.getElementById("e2p1cruz").style.display = "none";
	document.getElementById("e2p2tic").style.display  = "none";
	document.getElementById("e2p2cruz").style.display = "none";
	document.getElementById("e3p1tic").style.display  = "none";
	document.getElementById("e3p1reg").style.display  = "none";
	document.getElementById("e3p1cruz").style.display = "none";
	document.getElementById("e3p2tic").style.display  = "none";
	document.getElementById("e3p2reg").style.display  = "none";
	document.getElementById("e3p2cruz").style.display = "none";
	document.getElementById("e4p1tic").style.display  = "none";
	document.getElementById("e4p1cruz").style.display = "none";
	document.getElementById("e4p2tic").style.display  = "none";
	document.getElementById("e4p2cruz").style.display = "none";
	document.getElementById("e4p3tic").style.display  = "none";
	document.getElementById("e4p3cruz").style.display = "none";
	document.getElementById("e4p4tic").style.display  = "none";
	document.getElementById("e4p4cruz").style.display = "none";
	document.getElementById("e4p5tic").style.display  = "none";
	document.getElementById("e4p5cruz").style.display = "none";
	document.getElementById("e5p1tic").style.display  = "none";
	document.getElementById("e5p1cruz").style.display = "none";
	document.getElementById("e5p2tic").style.display  = "none";
	document.getElementById("e5p2cruz").style.display = "none";

}

function MarcarCorrectas(){
	
	document.getElementById("correctaE1P1").style.display = "block";
	document.getElementById("correctaE1P2").style.display = "block";
	document.getElementById("correctaE1P3").style.display = "block";
	document.getElementById("correctaE1P4").style.display = "block";
	document.getElementById("correctaE1P5").style.display = "block";

	document.getElementById("correctaE2P1").style.color = "green";
	document.getElementById("correctaE2P1").style.fontWeight = "bold";
	document.getElementById("correctaE2P2").style.color = "green";
	document.getElementById("correctaE2P2").style.fontWeight = "bold";

	document.getElementById("correcta1E3P1").style.color = "green";
	document.getElementById("correcta1E3P1").style.fontWeight = "bold";
	document.getElementById("correcta2E3P1").style.color = "green";
	document.getElementById("correcta2E3P1").style.fontWeight = "bold";
	document.getElementById("correcta1E3P2").style.color = "green";
	document.getElementById("correcta1E3P2").style.fontWeight = "bold";
	document.getElementById("correcta2E3P2").style.color = "green";
	document.getElementById("correcta2E3P2").style.fontWeight = "bold";

	document.getElementById("correctaE4P1").style.color = "green";
	document.getElementById("correctaE4P1").style.fontWeight = "bold";
	document.getElementById("correctaE4P2").style.color = "green";
	document.getElementById("correctaE4P2").style.fontWeight = "bold";
	document.getElementById("correctaE4P3").style.color = "green";
	document.getElementById("correctaE4P3").style.fontWeight = "bold";
	document.getElementById("correctaE4P4").style.color = "green";
	document.getElementById("correctaE4P4").style.fontWeight = "bold";
	document.getElementById("correctaE4P5").style.color = "green";
	document.getElementById("correctaE4P5").style.fontWeight = "bold";

	document.getElementById("correctaE5P1").style.display = "block";
	document.getElementById("correctaE5P2").style.display = "block";

}

document.getElementById("limpiarpantalla").onclick = function(){

	LimpiarRespuestas();
	puntajeObtenido = 0;

	document.getElementById("correctaE1P1").style.display = "none";
	document.getElementById("correctaE1P2").style.display = "none";
	document.getElementById("correctaE1P3").style.display = "none";
	document.getElementById("correctaE1P4").style.display = "none";
	document.getElementById("correctaE1P5").style.display = "none";

	document.getElementById("correctaE2P1").style.color = "black";
	document.getElementById("correctaE2P1").style.fontWeight = "normal";
	document.getElementById("correctaE2P2").style.color = "black";
	document.getElementById("correctaE2P2").style.fontWeight = "normal";

	document.getElementById("correcta1E3P1").style.color = "black";
	document.getElementById("correcta1E3P1").style.fontWeight = "normal";
	document.getElementById("correcta2E3P1").style.color = "black";
	document.getElementById("correcta2E3P1").style.fontWeight = "normal";
	document.getElementById("correcta1E3P2").style.color = "black";
	document.getElementById("correcta1E3P2").style.fontWeight = "normal";
	document.getElementById("correcta2E3P2").style.color = "black";
	document.getElementById("correcta2E3P2").style.fontWeight = "normal";

	document.getElementById("correctaE4P1").style.color = "black";
	document.getElementById("correctaE4P1").style.fontWeight = "normal";
	document.getElementById("correctaE4P2").style.color = "black";
	document.getElementById("correctaE4P2").style.fontWeight = "normal";
	document.getElementById("correctaE4P3").style.color = "black";
	document.getElementById("correctaE4P3").style.fontWeight = "normal";
	document.getElementById("correctaE4P4").style.color = "black";
	document.getElementById("correctaE4P4").style.fontWeight = "normal";
	document.getElementById("correctaE4P5").style.color = "black";
	document.getElementById("correctaE4P5").style.fontWeight = "normal";

	document.getElementById("correctaE5P1").style.display = "none";
	document.getElementById("correctaE5P2").style.display = "none";

}





		

